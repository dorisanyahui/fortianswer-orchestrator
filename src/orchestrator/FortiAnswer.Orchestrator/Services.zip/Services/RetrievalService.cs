namespace FortiAnswer.Orchestrator.Services;

using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using FortiAnswer.Orchestrator.Models;

public sealed class RetrievalBundle
{
    public string Context { get; set; } = "";
    public List<Citation> Citations { get; set; } = new();
}

public sealed class RetrievalService
{
    private readonly IHttpClientFactory _httpFactory;

    public RetrievalService(IHttpClientFactory httpFactory)
    {
        _httpFactory = httpFactory;
    }

    public async Task<RetrievalBundle> RetrieveAsync(
        string question,
        string? requestType,
        string? userGroup,
        int topK,
        string correlationId)
    {
        var mode = (Environment.GetEnvironmentVariable("RETRIEVAL_MODE") ?? "stub")
            .Trim().ToLowerInvariant();

        // Fallback to stub until you plug in real SEARCH_* values
        if (mode != "azureaisearch")
            return Stub(question, requestType, userGroup, topK, correlationId);

        var endpoint = Environment.GetEnvironmentVariable("SEARCH_ENDPOINT")?.Trim();
        var indexName = Environment.GetEnvironmentVariable("SEARCH_INDEX")?.Trim();
        var apiKey = Environment.GetEnvironmentVariable("SEARCH_API_KEY")?.Trim();
        var apiVersion = Environment.GetEnvironmentVariable("SEARCH_API_VERSION")?.Trim() ?? "2024-07-01";

        if (string.IsNullOrWhiteSpace(endpoint) ||
            string.IsNullOrWhiteSpace(indexName) ||
            string.IsNullOrWhiteSpace(apiKey) ||
            endpoint.Contains("<") || indexName.Contains("<") || apiKey.Contains("<"))
        {
            Console.WriteLine("[search] missing/placeholder SEARCH_* config; using stub retrieval");
            return Stub(question, requestType, userGroup, topK, correlationId);
        }

        // Make the request
        var client = _httpFactory.CreateClient();

        // POST https://{service}.search.windows.net/indexes/{index}/docs/search?api-version=...
        var url = $"{endpoint.TrimEnd('/')}/indexes/{indexName}/docs/search?api-version={apiVersion}";

        // Keep it simple for MVP: keyword search (simple query). Add filters later.
        var payload = new
        {
            search = question,
            top = topK,
            queryType = "simple",
            // If you know your field names, replace "*" with explicit fields for stability.
            select = "*"
        };

        Console.WriteLine($"[search] querying endpoint={endpoint} index={indexName} topK={topK}");

        var req = new HttpRequestMessage(HttpMethod.Post, url);
        req.Headers.Add("x-correlation-id", correlationId);
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        req.Headers.Add("api-key", apiKey);
        req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

        var resp = await client.SendAsync(req);
        var json = await resp.Content.ReadAsStringAsync();

        if (!resp.IsSuccessStatusCode)
        {
            Console.WriteLine($"[search.error] status={(int)resp.StatusCode} body={json}");
            // Fail-safe fallback so your chat still works in demo
            return Stub(question, requestType, userGroup, topK, correlationId);
        }

        // Azure Search returns: { "value": [ {doc}, {doc} ... ] }
        using var doc = JsonDocument.Parse(json);

        var citations = new List<Citation>();
        if (doc.RootElement.TryGetProperty("value", out var arr) && arr.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in arr.EnumerateArray())
            {
                // These field names depend on Keto's index schema.
                // We try common candidates so it works without re-coding immediately.
                var title =
                    GetString(item, "title") ??
                    GetString(item, "metadata_storage_name") ??
                    GetString(item, "name") ??
                    "Document";

                var idOrUrl =
                    GetString(item, "url") ??
                    GetString(item, "metadata_storage_path") ??
                    GetString(item, "metadata_storage_path") ??
                    GetString(item, "id") ??
                    "search://doc";

                var snippet =
                    GetString(item, "content") ??
                    GetString(item, "text") ??
                    GetString(item, "chunk") ??
                    GetString(item, "merged_content") ??
                    "";

                citations.Add(new Citation
                {
                    Title = title,
                    UrlOrId = idOrUrl,
                    Snippet = Truncate(snippet, 1200)
                });

                if (citations.Count >= topK) break;
            }
        }

        // Build LLM context from citations (trimmed)
        var header =
            $"[internal-evidence]\n" +
            $"requestType={requestType ?? ""}\n" +
            $"userGroup={userGroup ?? ""}\n" +
            $"topK={topK}\n" +
            $"source=azureaisearch\n";

        var body = citations.Count == 0
            ? "[no internal evidence found]"
            : string.Join("\n\n", citations.Select((c, i) =>
                $"[Chunk {i + 1}] {c.Title}\nSource: {c.UrlOrId}\n{c.Snippet}"
              ));

        return new RetrievalBundle
        {
            Context = header + "\n" + body,
            Citations = citations
        };
    }

    private static RetrievalBundle Stub(string question, string? requestType, string? userGroup, int topK, string correlationId)
    {
        var citations = new List<Citation>
        {
            new Citation
            {
                Title = "Internal KB (stub)",
                UrlOrId = "kb://stub/doc1#chunk1",
                Snippet = Truncate(
                    "Placeholder evidence. Replace with real retrieved text. " +
                    "When you integrate Azure AI Search chunks, this stub will be replaced.",
                    500
                )
            }
        };

        var context =
            $"[internal-evidence stub]\n" +
            $"topK={topK}\n" +
            $"requestType={requestType ?? ""}\n" +
            $"userGroup={userGroup ?? ""}\n" +
            $"question={question}\n\n" +
            string.Join("\n\n", citations.Select((c, i) => $"[Chunk {i + 1}] {c.Title}\n{c.Snippet}"));

        return new RetrievalBundle { Context = context, Citations = citations };
    }

    private static string? GetString(JsonElement obj, string name)
    {
        if (obj.ValueKind != JsonValueKind.Object) return null;
        if (!obj.TryGetProperty(name, out var p)) return null;
        if (p.ValueKind == JsonValueKind.String) return p.GetString();
        return null;
    }

    private static string Truncate(string? s, int maxChars)
    {
        if (string.IsNullOrEmpty(s)) return "";
        return s.Length <= maxChars ? s : s.Substring(0, maxChars) + "…";
    }
}
